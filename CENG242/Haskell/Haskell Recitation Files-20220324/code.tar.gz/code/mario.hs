data Character = Mario | Luigi | Yoshi

describe :: Character -> String
describe Mario = "It's-a me, Mario!"
describe Luigi = "The ultimate in second choice."
describe Yoshi = "Open the door, get on the floor..."
