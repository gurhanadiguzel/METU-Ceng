newtype Point = Point (Double, Double)
