firstNLast :: String -> String
firstNLast fullName = let nameList = words fullName -- splits on spaces
                          firstName = head nameList
                          lastName = last nameList
                       in [head firstName, '.', head lastName, '.']
