f :: Integer -> Integer
f x = x^2 + 3*x + 7

g :: Double -> Double -> Double
g x y = x * y + x

sumOfThree :: Int -> Int -> Int -> Int 
sumOfThree a b c = a + b + c

isA :: Char -> Bool
isA c = c == 'a' || c == 'A'
