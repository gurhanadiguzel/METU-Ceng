type ValPair = (Double, Double)
type String' = [Char] -- exactly how String is defined
type AssocList a b = [(a, b)] -- with type variables
