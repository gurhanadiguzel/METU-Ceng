data Adress = Info String String String String String String String -- ??
