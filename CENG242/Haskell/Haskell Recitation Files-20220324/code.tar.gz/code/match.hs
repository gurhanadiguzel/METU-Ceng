commentOnGrade :: String -> String
commentOnGrade "AA"  = "You rock, friend!"
commentOnGrade "BA"  = "Ah, must have been bad luck!"
commentOnGrade other = "You missed the Haskell recitation, didn't you?"
