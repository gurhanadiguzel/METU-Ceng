
f x = x^2 + 3*x + 7             -- polynomial
g x y = x * y + x               -- multivariate polynomial
sumOfThree a b c = a + b + c    -- sums its three arguments
isA c = c == 'a' || c == 'A'    -- checks whether the argument is an a
