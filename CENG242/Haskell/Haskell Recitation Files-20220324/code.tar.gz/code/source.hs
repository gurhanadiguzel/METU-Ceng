x = 3.0 -- also, here is single line comment!
y = 8.7
